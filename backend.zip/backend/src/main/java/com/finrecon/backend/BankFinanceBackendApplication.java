package com.finrecon.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankFinanceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankFinanceBackendApplication.class, args);
	}

}
