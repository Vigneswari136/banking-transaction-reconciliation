package com.finrecon.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankFinanceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
